﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeCPE
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void MENU_Click(object sender, EventArgs e)
        {
            Visible = false;
            App form2 = new App();
            form2.Visible = true;
        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            MessageBox.Show("แล้วพบกันใหม่โอกาศหน้าที่ร้าน CPE Cafe", "CPE Cafe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
    }
}
