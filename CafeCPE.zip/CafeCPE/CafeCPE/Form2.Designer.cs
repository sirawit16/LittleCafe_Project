﻿namespace CafeCPE
{
    partial class App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.C2 = new System.Windows.Forms.CheckBox();
            this.C3 = new System.Windows.Forms.CheckBox();
            this.C1 = new System.Windows.Forms.CheckBox();
            this.C4 = new System.Windows.Forms.CheckBox();
            this.C5 = new System.Windows.Forms.CheckBox();
            this.T1 = new System.Windows.Forms.CheckBox();
            this.T2 = new System.Windows.Forms.CheckBox();
            this.T3 = new System.Windows.Forms.CheckBox();
            this.T4 = new System.Windows.Forms.CheckBox();
            this.T5 = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.M1 = new System.Windows.Forms.CheckBox();
            this.M2 = new System.Windows.Forms.CheckBox();
            this.M3 = new System.Windows.Forms.CheckBox();
            this.M4 = new System.Windows.Forms.CheckBox();
            this.J1 = new System.Windows.Forms.CheckBox();
            this.J2 = new System.Windows.Forms.CheckBox();
            this.B1 = new System.Windows.Forms.CheckBox();
            this.B2 = new System.Windows.Forms.CheckBox();
            this.J3 = new System.Windows.Forms.CheckBox();
            this.J4 = new System.Windows.Forms.CheckBox();
            this.J5 = new System.Windows.Forms.CheckBox();
            this.B3 = new System.Windows.Forms.CheckBox();
            this.B4 = new System.Windows.Forms.CheckBox();
            this.Sum = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Confirm = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Order = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.Exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Linen;
            this.label1.Font = new System.Drawing.Font("Tempus Sans ITC", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(96, 227);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Coffee";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Linen;
            this.label2.Font = new System.Drawing.Font("Tempus Sans ITC", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(397, 227);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tea";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Linen;
            this.label3.Font = new System.Drawing.Font("Tempus Sans ITC", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkRed;
            this.label3.Location = new System.Drawing.Point(683, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 35);
            this.label3.TabIndex = 2;
            this.label3.Text = "Juice";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Linen;
            this.label4.Font = new System.Drawing.Font("Tempus Sans ITC", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkRed;
            this.label4.Location = new System.Drawing.Point(1230, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Bekery";
            // 
            // C2
            // 
            this.C2.AutoSize = true;
            this.C2.BackColor = System.Drawing.Color.Linen;
            this.C2.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.Location = new System.Drawing.Point(24, 295);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(252, 24);
            this.C2.TabIndex = 4;
            this.C2.Text = "Cappuccino                              45฿";
            this.C2.UseVisualStyleBackColor = false;
            // 
            // C3
            // 
            this.C3.AutoSize = true;
            this.C3.BackColor = System.Drawing.Color.Linen;
            this.C3.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.Location = new System.Drawing.Point(24, 325);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(250, 24);
            this.C3.TabIndex = 5;
            this.C3.Text = "Espresso                                    35฿";
            this.C3.UseVisualStyleBackColor = false;
            // 
            // C1
            // 
            this.C1.AutoSize = true;
            this.C1.BackColor = System.Drawing.Color.Linen;
            this.C1.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.ForeColor = System.Drawing.Color.Black;
            this.C1.Location = new System.Drawing.Point(24, 265);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(251, 24);
            this.C1.TabIndex = 6;
            this.C1.Text = " Black Coffee                            35฿";
            this.C1.UseVisualStyleBackColor = false;
            // 
            // C4
            // 
            this.C4.AutoSize = true;
            this.C4.BackColor = System.Drawing.Color.Linen;
            this.C4.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.Location = new System.Drawing.Point(24, 385);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(250, 24);
            this.C4.TabIndex = 7;
            this.C4.Text = "Latte                                        50฿";
            this.C4.UseVisualStyleBackColor = false;
            // 
            // C5
            // 
            this.C5.AutoSize = true;
            this.C5.BackColor = System.Drawing.Color.Linen;
            this.C5.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.Location = new System.Drawing.Point(24, 355);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(250, 24);
            this.C5.TabIndex = 8;
            this.C5.Text = "Mocha                                     50฿";
            this.C5.UseVisualStyleBackColor = false;
            // 
            // T1
            // 
            this.T1.AutoSize = true;
            this.T1.BackColor = System.Drawing.Color.Linen;
            this.T1.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T1.Location = new System.Drawing.Point(307, 265);
            this.T1.Name = "T1";
            this.T1.Size = new System.Drawing.Size(252, 24);
            this.T1.TabIndex = 10;
            this.T1.Text = "Green Tea                                 45฿";
            this.T1.UseVisualStyleBackColor = false;
            // 
            // T2
            // 
            this.T2.AutoSize = true;
            this.T2.BackColor = System.Drawing.Color.Linen;
            this.T2.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T2.Location = new System.Drawing.Point(307, 295);
            this.T2.Name = "T2";
            this.T2.Size = new System.Drawing.Size(250, 24);
            this.T2.TabIndex = 11;
            this.T2.Text = "Milk Tea                                  40฿";
            this.T2.UseVisualStyleBackColor = false;
            // 
            // T3
            // 
            this.T3.AutoSize = true;
            this.T3.BackColor = System.Drawing.Color.Linen;
            this.T3.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T3.Location = new System.Drawing.Point(307, 325);
            this.T3.Name = "T3";
            this.T3.Size = new System.Drawing.Size(252, 24);
            this.T3.TabIndex = 12;
            this.T3.Text = "Lamon Tea                               45฿";
            this.T3.UseVisualStyleBackColor = false;
            // 
            // T4
            // 
            this.T4.AutoSize = true;
            this.T4.BackColor = System.Drawing.Color.Linen;
            this.T4.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T4.Location = new System.Drawing.Point(307, 355);
            this.T4.Name = "T4";
            this.T4.Size = new System.Drawing.Size(251, 24);
            this.T4.TabIndex = 13;
            this.T4.Text = "Black Tea                                  35฿";
            this.T4.UseVisualStyleBackColor = false;
            // 
            // T5
            // 
            this.T5.AutoSize = true;
            this.T5.BackColor = System.Drawing.Color.Linen;
            this.T5.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T5.Location = new System.Drawing.Point(307, 385);
            this.T5.Name = "T5";
            this.T5.Size = new System.Drawing.Size(252, 24);
            this.T5.TabIndex = 14;
            this.T5.Text = "Tea                                           40฿";
            this.T5.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Linen;
            this.label6.Font = new System.Drawing.Font("Tempus Sans ITC", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkRed;
            this.label6.Location = new System.Drawing.Point(894, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(209, 35);
            this.label6.TabIndex = 15;
            this.label6.Text = "Milk/Chocolate";
            // 
            // M1
            // 
            this.M1.AutoSize = true;
            this.M1.BackColor = System.Drawing.Color.Linen;
            this.M1.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M1.Location = new System.Drawing.Point(871, 325);
            this.M1.Name = "M1";
            this.M1.Size = new System.Drawing.Size(245, 24);
            this.M1.TabIndex = 16;
            this.M1.Text = "Fresh Milk                               35฿";
            this.M1.UseVisualStyleBackColor = false;
            // 
            // M2
            // 
            this.M2.AutoSize = true;
            this.M2.BackColor = System.Drawing.Color.Linen;
            this.M2.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M2.Location = new System.Drawing.Point(871, 265);
            this.M2.Name = "M2";
            this.M2.Size = new System.Drawing.Size(248, 24);
            this.M2.TabIndex = 17;
            this.M2.Text = "Dark Chocolate                      40฿";
            this.M2.UseVisualStyleBackColor = false;
            // 
            // M3
            // 
            this.M3.AutoSize = true;
            this.M3.BackColor = System.Drawing.Color.Linen;
            this.M3.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M3.Location = new System.Drawing.Point(871, 295);
            this.M3.Name = "M3";
            this.M3.Size = new System.Drawing.Size(247, 24);
            this.M3.TabIndex = 18;
            this.M3.Text = "White Chocolate                   40฿";
            this.M3.UseVisualStyleBackColor = false;
            this.M3.CheckedChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            // 
            // M4
            // 
            this.M4.AutoSize = true;
            this.M4.BackColor = System.Drawing.Color.Linen;
            this.M4.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M4.Location = new System.Drawing.Point(871, 355);
            this.M4.Name = "M4";
            this.M4.Size = new System.Drawing.Size(244, 24);
            this.M4.TabIndex = 19;
            this.M4.Text = "Malt                                        35฿";
            this.M4.UseVisualStyleBackColor = false;
            // 
            // J1
            // 
            this.J1.AutoSize = true;
            this.J1.BackColor = System.Drawing.Color.Linen;
            this.J1.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J1.Location = new System.Drawing.Point(589, 265);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(249, 24);
            this.J1.TabIndex = 20;
            this.J1.Text = "Orange Juice                           30฿";
            this.J1.UseVisualStyleBackColor = false;
            // 
            // J2
            // 
            this.J2.AutoSize = true;
            this.J2.BackColor = System.Drawing.Color.Linen;
            this.J2.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J2.Location = new System.Drawing.Point(589, 325);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(249, 24);
            this.J2.TabIndex = 21;
            this.J2.Text = "Coconut Water                      20฿";
            this.J2.UseVisualStyleBackColor = false;
            // 
            // B1
            // 
            this.B1.AutoSize = true;
            this.B1.BackColor = System.Drawing.Color.Linen;
            this.B1.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(1150, 265);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(247, 24);
            this.B1.TabIndex = 22;
            this.B1.Text = "Doughnut                              20฿";
            this.B1.UseVisualStyleBackColor = false;
            // 
            // B2
            // 
            this.B2.AutoSize = true;
            this.B2.BackColor = System.Drawing.Color.Linen;
            this.B2.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(1150, 295);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(246, 24);
            this.B2.TabIndex = 23;
            this.B2.Text = "Cupcake                                  25฿";
            this.B2.UseVisualStyleBackColor = false;
            // 
            // J3
            // 
            this.J3.AutoSize = true;
            this.J3.BackColor = System.Drawing.Color.Linen;
            this.J3.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J3.Location = new System.Drawing.Point(589, 295);
            this.J3.Name = "J3";
            this.J3.Size = new System.Drawing.Size(250, 24);
            this.J3.TabIndex = 24;
            this.J3.Text = "Stawberry Juice                        35฿";
            this.J3.UseVisualStyleBackColor = false;
            // 
            // J4
            // 
            this.J4.AutoSize = true;
            this.J4.BackColor = System.Drawing.Color.Linen;
            this.J4.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J4.Location = new System.Drawing.Point(589, 385);
            this.J4.Name = "J4";
            this.J4.Size = new System.Drawing.Size(251, 24);
            this.J4.TabIndex = 25;
            this.J4.Text = "Grape Juice                              30฿";
            this.J4.UseVisualStyleBackColor = false;
            // 
            // J5
            // 
            this.J5.AutoSize = true;
            this.J5.BackColor = System.Drawing.Color.Linen;
            this.J5.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.J5.Location = new System.Drawing.Point(589, 355);
            this.J5.Name = "J5";
            this.J5.Size = new System.Drawing.Size(250, 24);
            this.J5.TabIndex = 26;
            this.J5.Text = "Apple Juice                              25฿";
            this.J5.UseVisualStyleBackColor = false;
            // 
            // B3
            // 
            this.B3.AutoSize = true;
            this.B3.BackColor = System.Drawing.Color.Linen;
            this.B3.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(1150, 325);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(246, 24);
            this.B3.TabIndex = 27;
            this.B3.Text = "Brownie                                  30฿";
            this.B3.UseVisualStyleBackColor = false;
            // 
            // B4
            // 
            this.B4.AutoSize = true;
            this.B4.BackColor = System.Drawing.Color.Linen;
            this.B4.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(1150, 355);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(244, 24);
            this.B4.TabIndex = 28;
            this.B4.Text = "Fruit Pie                                 30฿";
            this.B4.UseVisualStyleBackColor = false;
            // 
            // Sum
            // 
            this.Sum.BackColor = System.Drawing.Color.Linen;
            this.Sum.Font = new System.Drawing.Font("Tempus Sans ITC", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sum.Location = new System.Drawing.Point(470, 538);
            this.Sum.Multiline = true;
            this.Sum.Name = "Sum";
            this.Sum.Size = new System.Drawing.Size(254, 35);
            this.Sum.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Linen;
            this.label5.Font = new System.Drawing.Font("Tempus Sans ITC", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Brown;
            this.label5.Location = new System.Drawing.Point(319, 538);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 35);
            this.label5.TabIndex = 31;
            this.label5.Text = "Total price";
            // 
            // Confirm
            // 
            this.Confirm.Font = new System.Drawing.Font("Tempus Sans ITC", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Confirm.ForeColor = System.Drawing.Color.Firebrick;
            this.Confirm.Location = new System.Drawing.Point(494, 579);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(112, 34);
            this.Confirm.TabIndex = 35;
            this.Confirm.Text = "Confirm";
            this.Confirm.UseVisualStyleBackColor = true;
            this.Confirm.Click += new System.EventHandler(this.Confirm_Click);
            // 
            // Clear
            // 
            this.Clear.Font = new System.Drawing.Font("Tempus Sans ITC", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.ForeColor = System.Drawing.Color.Firebrick;
            this.Clear.Location = new System.Drawing.Point(612, 579);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(112, 34);
            this.Clear.TabIndex = 36;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click_2);
            // 
            // Order
            // 
            this.Order.BackColor = System.Drawing.Color.Linen;
            this.Order.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Order.Location = new System.Drawing.Point(24, 416);
            this.Order.Multiline = true;
            this.Order.Name = "Order";
            this.Order.Size = new System.Drawing.Size(289, 197);
            this.Order.TabIndex = 37;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CafeCPE.Properties.Resources._003;
            this.pictureBox1.Location = new System.Drawing.Point(24, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 200);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CafeCPE.Properties.Resources._012;
            this.pictureBox2.Location = new System.Drawing.Point(1150, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(250, 200);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 39;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::CafeCPE.Properties.Resources._008;
            this.pictureBox3.Location = new System.Drawing.Point(307, 24);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(250, 200);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 40;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::CafeCPE.Properties.Resources._009;
            this.pictureBox4.Location = new System.Drawing.Point(589, 24);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(250, 200);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 41;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::CafeCPE.Properties.Resources._011;
            this.pictureBox5.Location = new System.Drawing.Point(871, 24);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(250, 200);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 42;
            this.pictureBox5.TabStop = false;
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Tempus Sans ITC", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.ForeColor = System.Drawing.Color.Firebrick;
            this.Exit.Location = new System.Drawing.Point(1283, 579);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(111, 34);
            this.Exit.TabIndex = 43;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.BackgroundImage = global::CafeCPE.Properties.Resources._002;
            this.ClientSize = new System.Drawing.Size(1430, 646);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Order);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Sum);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.J5);
            this.Controls.Add(this.J4);
            this.Controls.Add(this.J3);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.J2);
            this.Controls.Add(this.J1);
            this.Controls.Add(this.M4);
            this.Controls.Add(this.M3);
            this.Controls.Add(this.M2);
            this.Controls.Add(this.M1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.T5);
            this.Controls.Add(this.T4);
            this.Controls.Add(this.T3);
            this.Controls.Add(this.T2);
            this.Controls.Add(this.T1);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "App";
            this.Text = "Menu Bar";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox C3;
        private System.Windows.Forms.CheckBox C1;
        private System.Windows.Forms.CheckBox C4;
        private System.Windows.Forms.CheckBox C5;
        private System.Windows.Forms.CheckBox T1;
        private System.Windows.Forms.CheckBox T2;
        private System.Windows.Forms.CheckBox T3;
        private System.Windows.Forms.CheckBox T4;
        private System.Windows.Forms.CheckBox T5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox M1;
        private System.Windows.Forms.CheckBox M2;
        private System.Windows.Forms.CheckBox M3;
        private System.Windows.Forms.CheckBox M4;
        private System.Windows.Forms.CheckBox J1;
        private System.Windows.Forms.CheckBox J2;
        private System.Windows.Forms.CheckBox B1;
        private System.Windows.Forms.CheckBox B2;
        private System.Windows.Forms.CheckBox J3;
        private System.Windows.Forms.CheckBox J4;
        private System.Windows.Forms.CheckBox J5;
        private System.Windows.Forms.CheckBox B3;
        private System.Windows.Forms.CheckBox B4;
        private System.Windows.Forms.TextBox Sum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox C2;
        private System.Windows.Forms.Button Confirm;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.TextBox Order;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button Exit;
    }
}