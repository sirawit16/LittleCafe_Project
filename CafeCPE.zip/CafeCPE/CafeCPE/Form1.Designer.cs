﻿namespace CafeCPE
{
    partial class Welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MENU = new System.Windows.Forms.Button();
            this.EXIT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MENU
            // 
            this.MENU.BackColor = System.Drawing.Color.LightGreen;
            this.MENU.Font = new System.Drawing.Font("Tempus Sans ITC", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MENU.ForeColor = System.Drawing.Color.Maroon;
            this.MENU.Location = new System.Drawing.Point(662, 241);
            this.MENU.Name = "MENU";
            this.MENU.Size = new System.Drawing.Size(250, 150);
            this.MENU.TabIndex = 0;
            this.MENU.Text = "Menu";
            this.MENU.UseVisualStyleBackColor = false;
            this.MENU.Click += new System.EventHandler(this.MENU_Click);
            // 
            // EXIT
            // 
            this.EXIT.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.EXIT.Font = new System.Drawing.Font("Tempus Sans ITC", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EXIT.ForeColor = System.Drawing.Color.Maroon;
            this.EXIT.Location = new System.Drawing.Point(662, 397);
            this.EXIT.Name = "EXIT";
            this.EXIT.Size = new System.Drawing.Size(250, 150);
            this.EXIT.TabIndex = 1;
            this.EXIT.Text = "Exit";
            this.EXIT.UseVisualStyleBackColor = false;
            this.EXIT.Click += new System.EventHandler(this.EXIT_Click);
            // 
            // Welcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CafeCPE.Properties.Resources.Cat;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1430, 646);
            this.Controls.Add(this.EXIT);
            this.Controls.Add(this.MENU);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.DoubleBuffered = true;
            this.Name = "Welcome";
            this.Text = " Welcome to CPE Cafe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button MENU;
        private System.Windows.Forms.Button EXIT;
    }
}

