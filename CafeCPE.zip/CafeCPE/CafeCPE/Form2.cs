﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CafeCPE
{
    public partial class App : Form
    {
        public App()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Order_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            string str;
            double Co1, Co2, Co3, Co4, Co5, Te1, Te2, Te3, Te4, Te5, Mi1, Mi2, Mi3, Mi4, Ju1, Ju2, Ju3, Ju4, Ju5, Be1, Be2, Be3, Be4, SUM;
            str = "";
            if (C1.Checked == true)
            {
                str += "\r\n\nBlackCoffee     Price 35฿";
                Co1 = 35;
            }
            else
            {
                Co1 = 0;
            }
            if (C2.Checked == true)
            {
                str += "\r\n\nCappuccino     Price 45฿";
                Co2 = 45;
            }
            else
            {
                Co2 = 0;
            }
            if (C3.Checked == true)
            {
                str += "\r\n\nEspresso    Price 35฿";
                Co3 = 35;
            }
            else
            {
                Co3 = 0;
            }
            if (C4.Checked == true)
            {
                str += "\r\n\nLatte     Price 50฿";
                Co4 = 50;
            }
            else
            {
                Co4 = 0;
            }
            if (C5.Checked == true)
            {
                str += "\r\n\nMocha     Price 50฿";
                Co5 = 50;
            }
            else
            {
                Co5 = 0;
            }
            if (T1.Checked == true)
            {
                str += "\r\n\nGreen Tea     Price 45฿";
                Te1 = 45;
            }
            else
            {
                Te1 = 0;
            }
            if (T2.Checked == true)
            {
                str += "\r\n\nMilk Tea     Price 40฿";
                Te2 = 40;
            }
            else
            {
                Te2 = 0;
            }
            if (T3.Checked == true)
            {
                str += "\r\n\nLemon Tea     Price 45฿";
                Te3 = 45;
            }
            else
            {
                Te3 = 0;
            }
            if (T4.Checked == true)
            {
                str += "\r\n\nBlack Tea     Price 35฿";
                Te4 = 35;
            }
            else
            {
                Te4 = 0;
            }
            if (T5.Checked == true)
            {
                str += "\r\n\nTea     Price 40฿";
                Te5 = 40;
            }
            else
            {
                Te5 = 0;
            }
            if (M1.Checked == true)
            {
                str += "\r\n\nFresh Milk     Price 35฿";
                Mi1 = 35;
            }
            else
            {
                Mi1 = 0;
            }
            if (M2.Checked == true)
            {
                str += "\r\n\nDark Chocolate     Price 40฿";
                Mi2 = 40;
            }
            else
            {
                Mi2 = 0;
            }
            if (M3.Checked == true)
            {
                str += "\r\n\nWhite Chocolate     Price 40฿";
                Mi3 = 40;
            }
            else
            {
                Mi3 = 0;
            }
            if (M4.Checked == true)
            {
                str += "\r\n\nMalt     Price 35฿";
                Mi4 = 35;
            }
            else
            {
                Mi4 = 0;
            }
            if (J1.Checked == true)
            {
                str += "\r\n\nOrange Juice     Price 30฿";
                Ju1 = 30;
            }
            else
            {
                Ju1 = 0;
            }
            if (J2.Checked == true)
            {
                str += "\r\n\nCoconut Water     Price 20฿";
                Ju2 = 20;
            }
            else
            {
                Ju2 = 0;
            }
            if (J3.Checked == true)
            {
                str += "\r\n\nStawberry Juice     Price 35฿";
                Ju3 = 35;
            }
            else
            {
                Ju3 = 0;
            }
            if (J4.Checked == true)
            {
                str += "\r\n\nGrape Juice     Price 30฿";
                Ju4 = 30;
            }
            else
            {
                Ju4 = 0;
            }
            if (J5.Checked == true)
            {
                str += "\r\n\nApple Juice     Price 25฿";
                Ju5 = 25;
            }
            else
            {
                Ju5 = 0;
            }
            if (B1.Checked == true)
            {
                str += "\r\n\nDoughnut     Price 20฿";
                Be1 = 20;
            }
            else
            {
                Be1 = 0;
            }
            if (B2.Checked == true)
            {
                str += "\r\n\nCupcake     Price 25฿";
                Be2 = 25;
            }
            else
            {
                Be2 = 0;
            }
            if (B3.Checked == true)
            {
                str += "\r\n\nBrownie     Price 30฿";
                Be3 = 30;
            }
            else
            {
                Be3 = 0;
            }
            if (B4.Checked == true)
            {
                str += "\r\n\nFruit Pie     Price 30฿";
                Be4 = 30;
            }
            else
            {
                Be4 = 0;
            }
            Order.Text = str;
            SUM = Co1 + Co2 + Co3 + Co4 + Co5 + Te1 + Te2 + Te3 + Te4 + Te5 + Mi1 + Mi2 + Mi3 + Mi4 + Ju1 + Ju2 + Ju4 + Ju3 + Ju5 + Be1 + Be2 + Be3 + Be4;
            Sum.Text = (SUM + "Bath");
        }

        private void Clear_Click_2(object sender, EventArgs e)
        {
            Order.Clear();
            Sum.Clear();
            C1.Checked = false;
            C2.Checked = false;
            C3.Checked = false;
            C4.Checked = false;
            C5.Checked = false;
            T1.Checked = false;
            T2.Checked = false;
            T3.Checked = false;
            T4.Checked = false;
            T5.Checked = false;
            M1.Checked = false;
            M1.Checked = false;
            M2.Checked = false;
            M3.Checked = false;
            M4.Checked = false;
            J1.Checked = false;
            J2.Checked = false;
            J3.Checked = false;
            J4.Checked = false;
            J5.Checked = false;
            B1.Checked = false;
            B2.Checked = false;
            B3.Checked = false;
            B4.Checked = false;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("See you next time at CPE Cafe", "CPE Cafe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }
    }
}
